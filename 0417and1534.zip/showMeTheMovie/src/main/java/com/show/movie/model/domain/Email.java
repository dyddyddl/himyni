package com.show.movie.model.domain;

import org.apache.ibatis.type.Alias;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Alias("email")
@ToString @Getter @Setter
public class Email {
		 
	    private String subject;
	    private String content;
	    private String receiver;


}
