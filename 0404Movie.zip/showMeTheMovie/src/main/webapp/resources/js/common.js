

$(function(){
	$('#header').load("/resources/common/header.html");
	//
})




