/**
 * 
 */

$(function(){
	$(".sighUpLogo").on('click',function(event){
		$(location).attr('href', '/');

	})
})
